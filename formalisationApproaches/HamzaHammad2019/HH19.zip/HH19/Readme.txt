
Contents:
1 Background
2 Running in Colab
3 Particular Techniques
4 Modifications for GKP
5 References
6 Contact
----------------------------



	1  Background

	        This task aims at implementing the formalising requirements in [1]. 

	        Using techniques including segmentation, tokenization, POS tagging, chunking,
	stemming, grammatical knowledge patterns in [2] and algorithms mentioned in [1] to 
	identify usecases and actors of the input text.  



	2  Running in Colab
	
	        To make sure the input text and 'gingerit.py' can be read correctly, please unzip 
	the folder 'HH19'  to the path: '/content/drive/MyDrive' (i.e. the 'My Drive' folder in 
	google colab), otherwise the corresponding content in the program would be changed.

	        Here are 2 notebooks corresponding to the original and the modified versions. 
	And the input texts are stroed in '/content/drive/MyDrive/HH19/inputs' .

	        After running blocks in the notebook, please call function 'hh19' to process the 
	input (.txt) text. The function can be edited to turn on/off chunking, stemming processing
	and customize chunking rules, system description and the system name. For more details
	please see the notes inside the notebook.

	        Results containing actors and usecases are stored as pairs of sets (i.e. (actor, usecase))
	inside a list, each element in this list corresponds to a user story. One user story may have 
	multiple 'actor-usecase' pairs because multiple GKPs may exist. If no GKP is found in a sentence,
	result would be shown as 'No GKP found.'



	3  Particular Techniques

	        Considering different techniques are used from various of sources. Here these
	techniques are listed below:

		· Spelling Check: 		Modified 'GingerIt.py' in [1] (modifing to avoid antibots, and the main 
					functionality of Ginger Spell Checker (GSC) is preserved, the modification 
					considering: https://github.com/Azd325/gingerit/issues/24#issuecomment-1024973609)

		· Segmentation: 		Method in [1]

		· Tokenization: 		'Algorithm 1' in [1]

		· POS tagging: 		Stanford POS Tagger in [2] (https://nlp.stanford.edu/software/stanford-tagger-4.2.0.zip)

		· Dependency Parsing:	Stanford Parser in [2] (https://nlp.stanford.edu/software/stanford-parser-4.2.0.zip)

		· Chunking:		RegexpParser in NLTK

		· Grammar Rules:		Grammar Knowledge Patterns (GKP) in [2]

		· Stemming:		Porter's Stemming Algorithm in NLTK



	4  Modifications for GKP
	
	        After testing the code on provided data, method in [2] is found not able to process sentences
	containing clauses. Additional frame structures are provided for identifying dependency tags from 
	clauses in modified GKP function, which is able to handle that problem.



	5  References

	        [1] Zahra Abdulkarim Hamza and Mustafa Hammad. Generating uml use case models from software requirements using natural language processing. In 2019 8th International Conference on Modeling Simulation and Applied Optimization (ICMSAO), pages 1–6. IEEE, 2019.
	        
	        [2] Bhatia, J., Sharma, R., Biswas, K. K., & Ghaisas, S. Using grammatical knowledge patterns for structuring requirements specifications. In IEEE third international workshop on requirements patterns, 2013. 



	6  Contact

	        For anything further, feel free to contact me:  lyq617uk@163.com
									Yiqi Liu